<?php
include('../connection/dbconn.php');
include ("../registration/session.php");
session_start();

if (!isset($_SESSION['username'])) {
  header('Location: ../login');
} 

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> User Dashboard </title>
  <link rel="stylesheet" href="style3.css">
  <!-- Boxicons CDN Link -->
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Wed Gala</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="user.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="links_name">Dashboard</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-calendar' ></i>
          <span class="links_name">Itinerary</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-list-check' ></i>
          <span class="links_name">Checklist</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-user-check' ></i>
          <span class="links_name">Guestlist</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-mail-send' ></i>
          <span class="links_name">Digital Invite</span>
        </a>
      </li>
      <li>
        <a href="#" class="active">
          <i class='bx bx-store-alt' ></i>
          <span class="links_name">Vendor</span>
        </a>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-message-detail' ></i>
          <span class="links_name">Feedback</span>
        </a>
      </li>
      <li class="log_out">
        <a href="../registration/logout.php">
          <i class='bx bx-log-out'></i>
          <span class="links_name">Log out</span>
        </a>
      </li>
    </ul>
  </div>

  <section class="home-section">

    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Vendor Shortlist</span>
      </div>
      <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search' ></i>
      </div>
      <div class="profile-details">
        <!-- <img src="images/profile.jpg" alt=""> -->
        <i class='bx bxs-user'></i>
        <span class="admin_name">
          <?php echo $_SESSION['username']; ?>
        </span>
      </div>
    </nav>

    <section class="blog" id="blog" style="padding-top: 80px;">

      <!-- Trigger/Open The Modal -->
      <button class="btn2" id="myBtn">+ ADD VENDOR</button>

      <!-- Vendor Category Section -->
      <div class="vendor-category">
        <div class="category-list-container">
          <ul class="category-list">
            <li class="category-item active">All</li>
            <li class="category-item">Venue</li>
            <li class="category-item">Caterer</li>
            <li class="category-item">Photographer</li>
            <li class="category-item">Brideswear</li>
            <li class="category-item">Groomswear</li>
            <li class="category-item">Planner</li>
            <li class="category-item">Make Up Artist</li>
            <li class="category-item">Door Gift</li>
            <li class="category-item">Florist</li>
            <li class="category-item">Cake</li>
            <li class="category-item">Videographer</li>
            <li class="category-item">Musician</li>
            <li class="category-item">Decoration</li>
          </ul>
        </div>
      </div>


      <!-- The Modal -->
      <div id="myModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
          <span class="close">&times;</span>
          <h2>Add Vendor</h2>
          <p>Please input the vendor details.</p>
          <div class="row">
            <div class="col-75">
              <div class="container1">

                <form name="add_vendor" method="POST" action="db_add_vendor.php" enctype="multipart/form-data">

                  <div class="row">
                    <div class="col-50">

                      <label for="vendor"><i class="fa fa-user"></i>Title</label>
                      <input type="text" id="vendor" name="vendor_name" placeholder="Vendor name" required>
                      <label for="price"><i class="fa fa-user"></i>Price</label>
                      <input type="text" id="price" name="vendor_price" placeholder="RM 0.00" required>
                      <label for="email"><i class="fa fa-envelope"></i> Email</label>
                      <input type="text" id="email" name="vendor_email" placeholder="Email address" required>

                    </div>

                    <div class="col-50">

                      <label for="contact"><i class="fa fa-address-card-o"></i> Contact</label>
                      <input type="text" id="contact" name="vendor_contact" placeholder="Phone number" required>

                      <label for="category">Category</label>
                      <select name="vendor_category" id="category" required>
                        <option value="Venue">Venue</option>
                        <option value="Caterer">Caterer</option>
                        <option value="Photographer">Photographer</option>
                        <option value="Brideswear">Brideswear</option>
                        <option value="Groomswear">Groomswear</option>
                        <option value="Planner">Planner</option>
                        <option value="Make Up Artist">Make Up Artist</option>
                        <option value="Door Gift">Door Gift</option>
                        <option value="Florist">Florist</option>
                        <option value="Cake">Cake</option>
                        <option value="Videogarpher">Videographer</option>
                        <option value="Musican">Musican</option>
                        <option value="Decoration">Decoration</option>
                      </select>


                      <label for="link">Link</label>
                      <input type="text" id="link" name="vendor_link" placeholder="http://" required>

                    </div>

                  </div>

                  <div class="container1" style="padding: 10px">

                    <label for="notes"><i class="fa fa-user"></i>Notes</label>
                    <textarea rows="4" cols="50" name="notes" required>Enter notes here...</textarea>

                  </div>

                  <input type="submit" name="submit" value="ADD VENDOR" class="btn1" onclick="myFunction()" >

                </form>

              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="box-container">

        <?php

// Retrieve vendors from the database
        $query = "SELECT * FROM vendor";
        $result = mysqli_query($dbconn, $query);

// Initialize the counter
        $counter = 1;

// Loop through the vendors and display them
        while ($row = mysqli_fetch_assoc($result)) {
          $vendorId = $row['vendor_id'];
          $vendorName = $row['vendor_name'];
          $vendorPrice = $row['vendor_price'];
          $vendorEmail = $row['vendor_email'];
          $vendorContact = $row['vendor_contact'];
          $vendorCategory = $row['vendor_category'];
          $vendorLink = $row['vendor_link'];
          $notes = $row['notes'];

// Generate HTML markup for each vendor
          echo '<div class="box" data-category="' . $vendorCategory . '">';
          echo '<img src="../images/blog-1.jpg" alt="">';
          echo '<div class="info">';
          echo '<h3 ><span>' . sprintf('%02d', $counter) . '. </span>' . $vendorName . '</h3>';
          echo '<p style="font-weight: bold;" ><strong>Price: </strong>RM' . $vendorPrice . '</p>';
          echo '<p style="font-weight: bold;" ><strong>Category: </strong>' . $vendorCategory . '</p>';
          echo '<p class="notes"><strong style="color: #98a2b3";>Notes: </strong></p>';
          echo '<p>' . $notes . '</p>';
          echo '<a href="#" class="btn" onclick="openModal(\'' . $vendorName . '\', \'' . $vendorPrice . '\', \'' . $vendorEmail . '\', \'' . $vendorContact . '\', \'' . $vendorCategory . '\', \'' . $notes . '\', \'' . $vendorLink . '\')">Learn More</a>';
          echo '</div>';
          echo '</div>';

// Increment the counter
          $counter++;
        }

// Free the result variable
        mysqli_free_result($result);

// Close the database connection
        mysqli_close($dbconn);
        ?>  

      </div>

      <!-- Modal -->
      <div id="vendorModal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="closeModal()">&times;</span>
          <h2>Vendor Details</h2>
          <img src="../images/blog-1.jpg" alt="Vendor Image" class="vendor-image">
          <h2 id="modalVendorName" class="vendor-title"></h2>
          <hr class="divider">
          <p id="modalVendorPrice" class="vendor-price"></p>
          <p id="modalVendorEmail" class="vendor-email"></p>
          <p id="modalVendorContact" class="vendor-contact"></p>
          <p id="modalVendorCategory" class="vendor-category1"></p>
          <p id="modalNotes" class="vendor-notes"></p>
          <a id="modalVendorLink" class="btn3">Visit Vendor</a>
        </div>
      </div>


    </section>

  </section>

  <script >
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function() {
      sidebar.classList.toggle("active");
      if(sidebar.classList.contains("active")){
        sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
      }else
      sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    }
  </script>

  <script>
// Get the modal
    var modal = document.getElementById("myModal");

// Get the button that opens the modal
    var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
    btn.onclick = function() {
      modal.style.display = "block";
    }

// When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }

// When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
  </script>

  <script>
    function myFunction() {
      alert("Vendor Added Successfully!");
    }
  </script>

  <script>
// Get all the category items
    var categoryItems = document.querySelectorAll(".category-item");

// Add click event listener to each category item
    categoryItems.forEach(function(item) {
      item.addEventListener("click", function() {
// Remove the "active" class from all category items
        categoryItems.forEach(function(item) {
          item.classList.remove("active");
        });

// Add the "active" class to the clicked category item
        item.classList.add("active");

// Get the category name
        var category = item.innerText;

// Get all the vendor boxes
        var vendorBoxes = document.querySelectorAll(".box");

        vendorBoxes.forEach(function(box) {
          var boxCategory = box.getAttribute("data-category");
          if (category === "All" || category === boxCategory) {
            box.style.display = "block";
          } else {
            box.style.display = "none";
          }
        });
      });
    });
  </script>

  <script>
// Open the modal and populate it with vendor information
    function openModal(name, price, email, contact, category, notes, link) {
      var modal = document.getElementById("vendorModal");
      var modalVendorName = document.getElementById("modalVendorName");
      var modalVendorPrice = document.getElementById("modalVendorPrice");
      var modalVendorEmail = document.getElementById("modalVendorEmail");
      var modalVendorContact = document.getElementById("modalVendorContact");
      var modalVendorCategory = document.getElementById("modalVendorCategory");
      var modalNotes = document.getElementById("modalNotes");
      var modalVendorLink = document.getElementById("modalVendorLink");

      modalVendorName.textContent = name;
      modalVendorPrice.textContent = "Price: RM" + price;
      modalVendorEmail.textContent = "Email: " + email;
      modalVendorContact.textContent = "Contact: " + contact;
      modalVendorCategory.textContent = "Category: " + category;
      modalNotes.textContent = "Notes: " + notes;
      modalVendorLink.href = link;

      modal.style.display = "block";
    }

// Close the modal when the user clicks the close button (×)
    var closeModalButton = document.getElementsByClassName("close-vendor")[0];
    closeModalButton.onclick = function () {
      var modal = document.getElementById("vendorModal");
      modal.style.display = "none";
    }


// Close the modal when the user clicks outside of it
    window.onclick = function (event) {
      var modal = document.getElementById("vendorModal");
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }

// Close the modal
    function closeModal() {
      var modal = document.getElementById("vendorModal");
      modal.style.display = "none";
    }


  </script>


</body>
</html>

<!-- Modal -->
      <div id="vendorModal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="closeModal()">&times;</span>
          <h2>Vendor Details</h2>
          <img src="../images/blog-1.jpg" alt="Vendor Image" class="vendor-image">
          <h2 id="modalVendorName" class="vendor-title"></h2>
          <hr class="divider">
          <p id="modalVendorPrice" class="vendor-price"></p>
          <p id="modalVendorEmail" class="vendor-email"></p>
          <p id="modalVendorContact" class="vendor-contact"></p>
          <p id="modalVendorCategory" class="vendor-category1"></p>
          <p id="modalNotes" class="vendor-notes"></p>
          <a id="modalVendorLink" class="btn3">Visit Vendor</a>
        </div>
      </div>